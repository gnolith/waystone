# Release checklist

1. Confirm semantic version, compatibility ranges, changelog, license, and clean
   Git state.
2. Run `npm ci && npm run check` on Node 22 and 24.
3. Run migration clean/upgrade tests and verify manifest checksums.
4. Inspect `npm pack --dry-run`; install the exact tarball in the canary.
5. Build the vinext/Vite Site and Worker without `nodejs_compat`.
6. Apply migrations to managed D1 and deploy the canary.
7. Run HTTP, browser, task/memory/SPARQL/knowledge semantic probes.
8. Initialize with an actual MCP client, inspect tools, perform representative
   calls, and prove anonymous/insufficient access fails.
9. Connect the intended Codex environment and capture one real MCP call.
10. Complete dependency/code/security review with no critical finding.
11. Record immutable release evidence, publish from a clean verified commit with
    provenance, and create the signed/tagged release artifact.

Any mandatory failure is NO-GO. See `release-evidence.md` for current evidence.
