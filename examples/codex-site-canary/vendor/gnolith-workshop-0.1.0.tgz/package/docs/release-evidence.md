# Workshop 0.1.0 release evidence

Current decision: **NO-GO** until all live deployment rows below have captured
evidence. Local green checks do not substitute for managed D1, deployed Worker,
Taproot projection, real MCP client, browser, or Codex calls.

| Gate                               | Evidence                                     | Status |
| ---------------------------------- | -------------------------------------------- | ------ |
| Build, types, lint, tests          | `npm run check`; 30 tests plus all gates     | PASS   |
| D1 clean migration and concurrency | Clean schema, checksum, and race tests       | PASS   |
| Worker no-compat dry run           | 640.24 KiB / 122.00 KiB gzip; no flags       | PASS   |
| Bundled Worker runtime             | Miniflare D1 authenticated MCP lifecycle     | PASS   |
| Exact tarball consumer             | About 73 KiB; every public subpath imported  | PASS   |
| Local official MCP client          | MCP SDK 1.29 connects, lists, and calls      | PASS   |
| Local performance regression       | Search/packet/MCP/knowledge/UI measured      | PASS   |
| Focused local security review      | Limits, auth/CORS, telemetry, audit, tarball | PASS   |
| Diamond no-compat host integration | 0.3.2 imports `node:events`                  | NO-GO  |
| Managed D1 migrations              | Cloudflare CLI is not authenticated          | NO-GO  |
| Deployed Worker/vinext canary      | Cloudflare CLI is not authenticated          | NO-GO  |
| Live task/memory/SPARQL probe      | Requires deployed real Diamond/Taproot Site  | NO-GO  |
| Live Taproot/RDF knowledge probe   | Requires deployed real Diamond/Taproot Site  | NO-GO  |
| Deployed actual MCP client         | No deploy target                             | NO-GO  |
| Browser smoke/accessibility        | No deployed vinext/Waystone canary           | NO-GO  |
| Intended Codex MCP call            | No deployed endpoint                         | NO-GO  |
