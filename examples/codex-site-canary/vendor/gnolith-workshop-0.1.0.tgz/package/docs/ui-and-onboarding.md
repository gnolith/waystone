# Waystone UI and onboarding

Import `workshopPlugin` and register it through Waystone's public structural
plugin contract. Import `@gnolith/workshop/styles.css` once in the Site shell.
Workshop does not import Waystone internals or touch D1 from browser code.

The plugin contributes Tasks and Memories navigation, routes, a dashboard,
related-task entity panel, research-seeding onboarding, and admin MCP status.
Exported components cover lists, filters, cards, state badges, detail, packets,
query results, claim/completion controls, editors, onboarding, and MCP status.
Status includes text/symbols, content is rendered as text, actions use semantic
controls, permission/conflict errors are explicit, and layouts are responsive.

Onboarding gathers language, topics, terms, people, places, objects, sources,
existing research, scope boundaries, and reusable guidance. `plan` returns the
small proposed seed; only an explicit `apply` writes ordinary Taproot Items,
memories, and tasks. It creates no project, ontology explosion, or agents.
`apply` accepts an explicit `expectedEmpty` precondition through the host's
`isEmpty` adapter. When all writers can participate in a shared transaction,
the host supplies `OnboardingServiceOptions.transaction`; Workshop runs the
entire apply operation inside it and propagates rollback failures.
